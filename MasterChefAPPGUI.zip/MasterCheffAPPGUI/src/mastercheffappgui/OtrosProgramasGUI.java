/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.*;
import static mastercheffappgui.MenuPrincipal.tabbedPane;

/**
 *
 * @author Administrador
 */
//creacion de clase con sus variables
class InfoProgramas{
    private  String NombreProg;
    private  int Temporadas;
    private  String añosemision;
    
    //metodo constructor para inicializar variables
   public InfoProgramas(String NombreProg,int Temporadas,String añosemision){
    this.NombreProg = NombreProg;
    this.Temporadas = Temporadas;
    this.añosemision = añosemision;
   }
   
   //metodos get y setpara mostrar y editar variables 
   public String getNombreProg(){

        return NombreProg;
     }
   
   public void setNombreProg(String NombreProg){
       this.NombreProg=NombreProg;
   } 
   
   public int getTemporadas(){
       
        return Temporadas;
    }
   
   public void setTemporadas(int Temporadas){
       this.Temporadas=Temporadas;
   }
   
   public String getañosemision(){
       return añosemision;
   }
   
   public void setañosemision(String añosemision){
       this.añosemision=añosemision;
   }
   
   public void Mostrarinfo(JTextArea textarea){
       textarea.append("\n-----------------PROGRAMA---------------------");
       textarea.append("\nNombre :"+NombreProg);
       textarea.append("\nTemporadas :"+Temporadas);
       textarea.append("\nAños de Emision :"+añosemision);
       textarea.append("\n                         ");
   }
}

public class OtrosProgramasGUI {
   
    private static List <InfoProgramas> ListaProgramas = new ArrayList<>();//creacion de lista para guardar informacion de programas
   
    
     public static void main(String[] args) {
        
           //instanciamos InfoPROGRAMAS y definimos sus variables .
     InfoProgramas MasterCheffColombia = new InfoProgramas("MasterChef colombia",2,"2015 y 2016");
     ListaProgramas.add(MasterCheffColombia);
     InfoProgramas MasterCheffJunior = new InfoProgramas("MasterChef Junior",1,"2015");
     ListaProgramas.add(MasterCheffJunior);
     InfoProgramas MasterCheffCelebrity = new InfoProgramas("MasterChef Celebrity",5,"2018,2019,2021,2022 y 2023");
     ListaProgramas.add(MasterCheffCelebrity);

     
  
    
    
    JLabel programas=new JLabel("Otros Programas Master Chef Colombia :");
    JTextArea textarea=new JTextArea();
    JScrollPane scroll=new JScrollPane(textarea);
    
    JPanel Programas =new JPanel(new GridLayout (2,1));
     Programas.setLayout(new BoxLayout (Programas, BoxLayout.Y_AXIS));
    
        
        Programas.add(programas);
        Programas.add(scroll);
        
      for(InfoProgramas master:ListaProgramas){
            master.Mostrarinfo(textarea);
        }
     
     tabbedPane.addTab("Otros Programas", Programas);
    }
}
