/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author alexi
 */
public class RegistroInicioGUI extends MenuPrincipal {
    
    static boolean UserRegistrado=false;
    static String Usuario="";
    static String Password="";
    
    public RegistroInicioGUI(String Usuario,String Password) {
    Usuario = this.Usuario;
    Password = this.Password;
    }
    
    public String getUsuario(){
    
        return Usuario;
    }
    public String getPassword(){
    
        return Password;
    }
    
    public static void Registro(){
        JFrame frameregistro=new JFrame("REGISTRO");
        
        JButton botonregistro = new JButton("Registrarse");
        
        JLabel usuario=new JLabel("Usuario :");
        JTextField campousuario = new JTextField();
        
        JLabel password=new JLabel("Contraseña :");
        JPasswordField campoPassword = new JPasswordField();
        
        JLabel espacio=new JLabel("        ");
        
        
         botonregistro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 if(!UserRegistrado){             
                 Usuario = campousuario.getText();
                 Password = campoPassword.getText();
                if(!Usuario.isEmpty() && !Password.isEmpty()){
                     UserRegistrado=true;
                 JOptionPane.showMessageDialog(frameregistro, "Bienvenido te Has Registrado "+Usuario+"!");
                 } 
                 else{
                     JOptionPane.showMessageDialog(frameregistro, "Ingresa Valores en cada casilla para el registro");
                     return;
                 }
                 }
                frameregistro.dispose();
               iniciosesion();
            }

            
         });
         
         JPanel panel = new JPanel(new GridLayout(3, 1)); 
         
         panel.add(usuario);
         panel.add(campousuario);
         panel.add(espacio);
         panel.add(password);
         panel.add(campoPassword);
         panel.add(espacio);
         panel.add(botonregistro);
         
         
         frameregistro.add(panel);
         
        
         frameregistro.setLayout(new FlowLayout());

         // Establecer el tamaño de la ventana
         frameregistro.setSize(300, 150);
         frameregistro.setLocationRelativeTo(null);

         // Establecer la operación de cierre predeterminada
         frameregistro.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

         // Hacer que la ventana sea visible
         frameregistro.setVisible(true);
    }
    public static void iniciosesion(){
      
       JFrame frameinicio=new JFrame("Inicio Sesion");
        
        JButton botoninicio = new JButton("Iniciar Sesion");
        JButton botondatos = new JButton("Olvide Datos");
        
        JLabel usuario=new JLabel("Usuario :");
        JTextField campousuario = new JTextField();
        
        JLabel password=new JLabel("Contraseña :");
        JPasswordField campoPassword = new JPasswordField();
        
       
        
        
         botoninicio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(UserRegistrado){
                 String confirmarUser = campousuario.getText();
                 String confirmarPass = campoPassword.getText();
                 if(confirmarUser.equals(Usuario) && confirmarPass.equals(Password)){
              
                    JOptionPane.showMessageDialog(frameinicio,"Bienvenido "+Usuario+" Has Iniciado Sesion");
                    
                    String[] args = null;
                    frameinicio.dispose();
                
                    MenuPrincipal.main(args);//llamar main menuprincipal cuando se confirme que los datos son correctos
                   }
                 else if(!confirmarUser.equals(Usuario) && !confirmarPass.equals(Password)){
                        JOptionPane.showMessageDialog(frameinicio,"Datos Incorrectos,\nutiliza el boton Datos"+
                                "\nsi no te acuerdas de los datos");
                    }
                 else if(!confirmarUser.equals(Usuario) && confirmarPass.equals(Password)){
                        JOptionPane.showMessageDialog(frameinicio,"Datos Incorrectos,\nutiliza el boton Datos"+
                                "\nsi no te acuerdas de los datos");
                    }
                 else if(confirmarUser.equals(Usuario) && !confirmarPass.equals(Password)){
                        JOptionPane.showMessageDialog(frameinicio,"Datos Incorrectos,\nutiliza el boton Datos"+
                                "\nsi no te acuerdas de los datos");
                    }
                 else if(confirmarUser.equals("") && confirmarPass.equals("")){
                        JOptionPane.showMessageDialog(frameinicio,"Datos Incorrectos,\nutiliza el boton Datos"+
                                "\nsi no te acuerdas de los datos");
                    }
                  

                }
                           }
         });
         
         botondatos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               
                 
                JOptionPane.showMessageDialog(frameinicio,"tu nombre de usuario es "+Usuario+
                        "\n tu contraseña es "+Password);
            }
         });
         
         JPanel panel = new JPanel(new GridLayout(3, 1)); 
         
         panel.add(usuario);
         panel.add(campousuario);
         panel.add(new JLabel());
         panel.add(password);
         panel.add(campoPassword);
         panel.add(new JLabel());
         panel.add(botoninicio);
         panel.add(botondatos);
         
         
         frameinicio.add(panel);
         
        
         frameinicio.setLayout(new FlowLayout());

         // Establecer el tamaño de la ventana
         frameinicio.setSize(600, 150);
         frameinicio.setLocationRelativeTo(null); 
         // Establecer la operación de cierre predeterminada
         frameinicio.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

         // Hacer que la ventana sea visible
         frameinicio.setVisible(true);
    }
    
    public static void main(String[] args) {
        Registro();
    }
}
