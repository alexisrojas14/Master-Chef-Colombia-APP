/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mastercheffappgui;

import java.awt.FlowLayout;
import javax.swing.*;
import javax.swing.JOptionPane;

/**
 *
 * @author alexi
 */
public class MasterCheffAPPGUI {

    /**
     * @param args the command line arguments
     */
    public static void saludo(){
        
        
        Object[] opcion = {"Siguiente"};//array con la opcion siguiente

        // Mostrar un cuadro de diálogo con opciones de botón personalizadas
        int resultado = JOptionPane.showOptionDialog(
                null,
                "Hola,Bienvenido a Master Cheff Colombia APP."+
                        "\nDale en Siguiente para Registrarte",//mensaje del joption pane
                "Bienvenida",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
         
    }
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        saludo();
        RegistroInicioGUI.Registro();
        
    }
    
}
