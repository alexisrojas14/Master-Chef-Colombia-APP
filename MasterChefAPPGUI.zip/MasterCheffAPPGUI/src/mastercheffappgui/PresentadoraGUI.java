/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.*;
import javax.swing.JTextArea;
import static mastercheffappgui.MenuPrincipal.tabbedPane;

/**
 *
 * @author Administrador
 */
public class PresentadoraGUI extends Persona {
     public static void main(String[] args) {
     
         PresentadoraGUI claudia = new PresentadoraGUI("Claudia Bahamon","colombiana",44,"presentadora");
    JLabel text = new JLabel("La Presentadora de Master Chef Colombia es :");
   
    JPanel Presentadora =new JPanel(new GridLayout (2,1));
    Presentadora.setLayout(new BoxLayout (Presentadora, BoxLayout.Y_AXIS));
    JTextArea textarea=new JTextArea();
    
    JScrollPane scroll=new JScrollPane(textarea);
    
    textarea.append(claudia.toString());
   
    
      List<Integer> participantes = new ArrayList<>();//creamos una lista de tipo entero para agregar el numero de participantes
     participantes.add(24);
        
          for(Integer Numpar : participantes){//definimos lista en una variable
          textarea.append("\ny La cantidad de participantes es "+Numpar);//imprimir mensaje y llamar variable Numpar que muestra la lista
            }
          
          
          
          Presentadora.add(text);
          Presentadora.add(scroll);
          
     tabbedPane.addTab("Presentadora ", Presentadora);
    }

    public PresentadoraGUI(String Nombre, String Nacionalidad, int Edad, String Profesion) {
        super(Nombre, Nacionalidad, Edad, Profesion);
    }
}
