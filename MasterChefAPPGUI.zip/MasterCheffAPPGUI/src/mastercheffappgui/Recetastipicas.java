/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import static mastercheffappgui.MenuPrincipal.tabbedPane;

/**
 *
 * @author alexi
 */
class Recetas{
    private String NombreReceta;
  private String OrigenReceta;
  private String TiempoCocina;
  private String Ingredientes;
  
  
  
 
  public Recetas(String NombreReceta,String OrigenReceta,String TiempoCocina,String Ingredientes){
      this.NombreReceta = NombreReceta;
      this.OrigenReceta = OrigenReceta;
      this.TiempoCocina = TiempoCocina;
      this.Ingredientes = Ingredientes; 
    }
  
  public String getNombreReceta(){
    
      return NombreReceta;
    } 
  public void setNombreReceta(String NombreReceta){
      this.NombreReceta = NombreReceta;
    }
  
  public String getOrigenReceta(){
    
      return OrigenReceta;
    } 
  
  public void setOrigenReceta(String OrigenReceta){
      this.OrigenReceta = OrigenReceta;
    }
  
  public String getTiempoCocina(){
      
      return TiempoCocina;
    } 
  public void setTiempoCocina(String TiempoCocina){
      this.TiempoCocina = TiempoCocina;
    }
  
  public String getIngredientes(){
      
      return Ingredientes;
    }
  public void setIngredientes(String Ingredintes){
      this.Ingredientes = Ingredientes;
  }
  
  public void MostrarRecetas(JTextArea recetasTextArea) {
       
      
    recetasTextArea.append("\n____________________RECETA______________________");
    recetasTextArea.append("                                                   ");
    recetasTextArea.append("\nNombre de la receta: " + NombreReceta + "\nOrigen de la Receta: " + OrigenReceta +
            "\nTiempo de Preparacion: " + TiempoCocina + "\n Ingredientes: " + Ingredientes);

    recetasTextArea.append("\n                                                   ");
   
}
}
public class Recetastipicas{
private static List<Recetas> ListaRecetas = new ArrayList<>();
private static JTextArea recetasTextArea = new JTextArea();
   
  
 
  public static void VerRecetas(JTextArea recetasTextArea) {
        JFrame framerecetas = new JFrame("Recetas Tipicas Colombianas");
        framerecetas.setLayout(new BorderLayout());
        JButton salir = new JButton("Salir menu principal");

        salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                recetasTextArea.setText("");
                framerecetas.dispose();
            }
        });

        // Limpiar el contenido actual del JTextArea
        recetasTextArea.setText("");

        JPanel panelrecetas = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;

        panelrecetas.add(new JLabel("Recetas Tipicas Colombianas"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        panelrecetas.add(new JScrollPane(recetasTextArea), gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.NONE; // Restablecemos la propiedad fill a NONE para el botón.
        gbc.weightx = 0.0;
        gbc.weighty = 0.0;
        panelrecetas.add(salir, gbc);

        framerecetas.add(panelrecetas);
        // Establecer el tamaño de la ventana
        framerecetas.setSize(700, 700);
        framerecetas.setLocationRelativeTo(null);

        // Establecer la operación de cierre predeterminada
        framerecetas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Hacer que la ventana sea visible
        framerecetas.setVisible(true);

        // Mostrar las recetas en el JTextArea
        for (Recetas receta : ListaRecetas) {
            receta.MostrarRecetas(recetasTextArea);
        }
            }
  
  public static void AgregarRecetas(){
      JFrame frameagregar=new JFrame("Agregar Receta");
      frameagregar.setSize(600, 600);
        frameagregar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameagregar.setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        
        JLabel introduce=new JLabel("Ingresa Los Siguientes Datos :");
        JLabel nombrerec=new JLabel("Nombre De la Receta:");
        JTextField campoNombrerec=new JTextField();
        campoNombrerec.setColumns(15);
        JLabel origen =new JLabel("Origen de la Receta:");
        JTextField campoOrigenrec=new JTextField();
        campoOrigenrec.setColumns(15);
        JLabel Tiempo =new JLabel("Tiempo de Preparacion:");
        JTextField campoTiemporec=new JTextField();
        campoTiemporec.setColumns(15);
        JLabel Ingredientes =new JLabel("Ingredientes:");
        JTextField campoIngredientesrec=new JTextField();
        campoIngredientesrec.setColumns(15);
        
        JButton Agregarrec = new JButton("Agregar Receta");
        JButton salirrec = new JButton("Salir Menu Principal");
        
        Agregarrec.addActionListener(new ActionListener(){
      @Override
      public void actionPerformed(ActionEvent e){
            String nombreReceta = campoNombrerec.getText();
            String origenReceta = campoOrigenrec.getText();
            String tiempoCocina = campoTiemporec.getText();
            String ingredientes = campoIngredientesrec.getText();
            
            //se instancia una nueva receta agregando sos valores en ordencon las variables creadas en Recetas
        Recetas nuevaReceta = new Recetas(nombreReceta, origenReceta, tiempoCocina, ingredientes);
        ListaRecetas.add(nuevaReceta);//se añade la nueva receta a la lista creada
        
        
        
        JOptionPane.showInternalMessageDialog(null, "Receta agregada exitosamente.");
         
        frameagregar.dispose();
        }
  });
        salirrec.addActionListener(new ActionListener(){
          @Override
          public void actionPerformed(ActionEvent e) {
             frameagregar.dispose();
          }
            
        });
    
       
          JPanel panelAgregar = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6); // Márgenes internos

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelAgregar.add(introduce, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelAgregar.add(nombrerec, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        panelAgregar.add(campoNombrerec, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panelAgregar.add(origen, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        panelAgregar.add(campoOrigenrec, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panelAgregar.add(Tiempo, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        panelAgregar.add(campoTiemporec, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panelAgregar.add(Ingredientes, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        panelAgregar.add(campoIngredientesrec, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        panelAgregar.add(Agregarrec, gbc);
        
        gbc.gridx=0;
        gbc.gridy=6;
        gbc.gridwidth=2;
        panelAgregar.add(salirrec,gbc);

        frameagregar.add(panelAgregar);
        frameagregar.setVisible(true);
    
  }

    public static void main(String[] args) {
        
       Recetas Arepas = new Recetas("Arepas Caseras", "Disputa De Origen Entre Barranquilla y Cartagena", "32 Minutos",
            "Harina de Maiz precocida blanca ,Agua fría, Sal cucharadita de postre,Queso rallado para el relleno Pechuga de pollo cocida para el relleno");
    ListaRecetas.add(Arepas);

    Recetas Ajiaco = new Recetas("Ajiaco Colombiano", " Santa Fe de Bogota", "1 hora Aprox.",
            "\npapa pastusa, papa criolla,cebolla,pollo,cilantro,ajo,hierbas,sal,maiz cocido,pimienta negra");
    ListaRecetas.add(Ajiaco);

    Recetas arrozconpollo = new Recetas("Arroz con Pollo", " China", "1.5 horas Aprox.",
            "\nsalsa de tomate, caldo de gallina,salsa de soya,pollo desmechado,arroz,ajo,hierbas,sal,arverja,zanahoria,habichuela,raices");
    ListaRecetas.add(arrozconpollo); 

        
         JPanel recetaspanel = new JPanel();
          recetaspanel.setLayout(new GridLayout(4, 1));
         
         JLabel selecciona=new JLabel("Selecciona una Opcion : ");
         
         JButton recetascol = new JButton("Ver Recetas");
         JButton agregarrec = new JButton("Agregar Recetas");
         JButton tienda = new JButton("Tienda");
         
         
          
    
         recetascol.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e){
                 // Se muestran las recetas directamente en el JTextArea sin agregar a ListaRecetas
        
                  recetasTextArea.setText("");
                
                 VerRecetas(recetasTextArea);
                 
           
             }
         });
         
         agregarrec.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e){
                 AgregarRecetas();
                
                 
         }
         });
         
         tienda.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e){
                 TiendaGUI.main(args);
         }
         });
         
       
        
        JPanel labelPanel = new JPanel();
        labelPanel.add(selecciona);
        labelPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        recetaspanel.add(labelPanel);
         
         
         
       JPanel botonesPanel = new JPanel(new GridLayout(3, 1));
        botonesPanel.add(recetascol);
        botonesPanel.add(agregarrec);
        botonesPanel.add(tienda);
        botonesPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        recetaspanel.add(botonesPanel);
        
          botonesPanel.setBorder(new EmptyBorder(5, 0, 5, 0));
          tabbedPane.addTab("Recetas Tipicas", recetaspanel);
    }
}
