/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

/**
 *
 * @author alexi
 */
public class Pseudocodigo {
    //Pseudcodigo PROGRAMA Master Chef Colombia APP

//el usuario ejecuta el programa
//INCIO PROGRAMA

//programa muestra mensaje de bienvenida con opcion siguiente

//muestra de frame Registro para que el usuario se registre

//con el usuario registrado muestra frame de inicion de sesion

//usuario debera ingresar los mismos datos con los cuales se registro

//ya con la sesion inciada , muestra frame de menu principal

//menu principal tiene 7 ventanas para el usuario donde accedera a informacion diferente.

//si el usuario selecciona la primer ventana recetas tipicas
//tendra visible 3 botones llamdos ver recetas,agregar recetas y tienda,si
//usuario oprime el boton ver recetas mostrara recetas tipicas colombianas
//si el usuario oprime boton agregar recetas ,el usuario podra agregar sus recetas y verlas en el boton de ver recetas.
//si el usuario oprime boton Tienda , podra ver una tabla con ingredientes de las recetas y sus precios.

//si el usuario cambia a la segunda ventana cocina podra conocer el paso a paso para cocinar algunas recetas.
//tendra 3 recetas por opcion para conocer su paso a paso
//si el usuario selecciona arepas caseras y da a boton cocinar accedera al paso a paso para cocinar arepas caseras.
//si el usuario selecciona ajiaco y da a boton cocinar accedera al paso a paso para cocinar ajiaco.
//si el usuario selecciona arroz con pollo y da a boton cocinar accedera al paso a paso para cocinar arroz con pollo.

//si el usuario cambia a la tercer ventana accedera a la informacion de los gandores de master cheff colombia

//si el usuario cambia a la cuarta ventana jurados tendra tres opcion en las cuales en cada una muestra informacion de un jurado diferente cada una.

//si el usuario cambia a la quinta ventana presentadora conocera informacion de la presentadora de master chef y numero de personas que participan en el programa.

//si el usuario cambia a la sexta ventana otro programas ,conocera a otros programas emitidos de master chef en colombia .

//si el usuario cambia a la ventana creditos ,conocera informacion del desarrollador del programa y un boton llamado cerrar programa.
//si el usuario oprime boton cerrar programa,muestra mensaje de despedida.

//FIN PROGRAMA.


}
