/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import static mastercheffappgui.MenuPrincipal.tabbedPane;

/**
 *
 * @author alexi
 */
public class CocinaGUI extends MenuPrincipal {
     private static String Plato="";
     private static Object[] opcion = {"Siguiente"};//array con la opcion siguiente
     private static Object[] opcion1 = {"Terminar"};//array con la opcion siguiente
     private static JProgressBar progressBar;
     
public static void cocinarArepas(){
    Plato = "Arepas Caseras";
    
       SwingUtilities.invokeLater(() -> progressBar.setValue(0));
        // Mostrar un cuadro de diálogo con opciones de botón personalizadas
        JOptionPane.showOptionDialog(
                null,
                "Hola, hoy vamos a cocinar " + Plato,//mensaje del joption pane
                "Paso 1",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(25); 
    });
        JOptionPane.showOptionDialog(
                null,
               "Iniciaremos a hacer la masa, agarra la harina de maíz, agua y sal"+
                       "\nOprime siguiente  para iniciar a mezclar",//mensaje del joption pane
                "Paso 2",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(50); 
    });
        JOptionPane.showOptionDialog(
                null,
              "Mezclando ingredientes......",//mensaje del joption pane
                "Paso 3",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(75); 
    });
        JOptionPane.showOptionDialog(
                null,
              "Después de 6 minutos...................",//mensaje del joption pane
                "Paso 4",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion1,//array que creamos
                opcion1[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(100); 
    });
        
        JOptionPane.showMessageDialog(null,Plato +" Bien Cocinadas! Listas para aplicar relleno si quieres....");
}
public static void cocinarAjiaco(){
    Plato="Ajiaco Colombiano";
     SwingUtilities.invokeLater(() -> progressBar.setValue(0));
    // Mostrar un cuadro de diálogo con opciones de botón personalizadas
        JOptionPane.showOptionDialog(
                null,
                "Hola, hoy vamos a cocinar " + Plato,//mensaje del joption pane
                "Paso 1",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
         SwingUtilities.invokeLater(() -> {
        progressBar.setValue(15); 
    });
        JOptionPane.showOptionDialog(
                null,
               "iniciaremos a Pelar y cortar las papas,cebolla para el Ajiaco"+
                       "\nOprime siguiente  para iniciar iniciar a pelar y cortar la papa y cebolla",//mensaje del joption pane
                "Paso 2",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
         SwingUtilities.invokeLater(() -> {
        progressBar.setValue(25); 
    });
        JOptionPane.showOptionDialog(
                null,
              "cortando papa y cebolla......",//mensaje del joption pane
                "Paso 3",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
         SwingUtilities.invokeLater(() -> {
        progressBar.setValue(35); 
    });
         JOptionPane.showOptionDialog(
                null,
              "¡Papa y cebolla !Lista para ser cocinadas",//mensaje del joption pane
                "Paso 4",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(45); 
    });
         JOptionPane.showOptionDialog(
                null,
              "oprime siguiente para iniciar a cocinar todos los ingredientes",//mensaje del joption pane
                "Paso 5",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(55); 
    });
         JOptionPane.showOptionDialog(
                null,
              "iniciando a cocinar......",//mensaje del joption pane
                "Paso 6",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(65); 
    });
         JOptionPane.showOptionDialog(
                null,
              " introduciendo a la olla,papa,cilantro,pollo pimentado ,cebolla,sal y demas ingredientes...........",//mensaje del joption pane
                "Paso 7",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(75); 
    });
         JOptionPane.showOptionDialog(
                null,
              "olla lista para ser tapada y ponerse a cocinar",//mensaje del joption pane
                "Paso 8",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(85); 
    });
         JOptionPane.showOptionDialog(
                null,
              "oprime siguiente para Ponerle la tapa a la olla",//mensaje del joption pane
                "Paso 9",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(88); 
    });
         JOptionPane.showOptionDialog(
                null,
              "iniciando a cocinar ajiaco a fuego bajito......",//mensaje del joption pane
                "Paso 10",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(90); 
    });
         JOptionPane.showOptionDialog(
                null,
              "despues de 45 minutos cocinando....               ",//mensaje del joption pane
                "Paso 11",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(94); 
    });
         JOptionPane.showOptionDialog(
                null,
              "destapamos la olla ,sacamos el pollo y los desmechamos",//mensaje del joption pane
                "Paso 12",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(96); 
    });
         JOptionPane.showOptionDialog(
                null,
              "oprime siguiente para Poner el pollo desmechado de nuevo, el maiz y guascas en la olla y dejarla destapada ",//mensaje del joption pane
                "Paso 13",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(98); 
    });
         JOptionPane.showOptionDialog(
                null,
              "Cocinando 10 minutos mas el ajico con la tapa destapada......",//mensaje del joption pane
                "Paso 14",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion1,//array que creamos
                opcion1[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
          SwingUtilities.invokeLater(() -> {
        progressBar.setValue(100); 
    });
         JOptionPane.showMessageDialog(null,Plato +" listo para ser consumido con aguacate ....");
         
}
public static void cocinarArrozConPollo(){
    Plato="Arroz con Pollo";
     SwingUtilities.invokeLater(() -> progressBar.setValue(0));
     // Mostrar un cuadro de diálogo con opciones de botón personalizadas
        JOptionPane.showOptionDialog(
                null,
                "Hola, hoy vamos a cocinar " + Plato,//mensaje del joption pane
                "Paso 1",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(15); 
    });
        JOptionPane.showOptionDialog(
                null,
                "iniciaremos poniendo a cocinar la pechuga y hacer el guiso para el arroz",//mensaje del joption pane
                "Paso 2",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(25); 
    });
        JOptionPane.showOptionDialog(
                null,
                "oprime siguiente para iniciar a cocinar pechuga y preparar guiso para el arroz",//mensaje del joption pane
                "Paso 3",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(35); 
    });
        JOptionPane.showOptionDialog(
                null,
                "cocinando pechuga y guizo.....",//mensaje del joption pane
                "Paso 4",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(40); 
    });
        JOptionPane.showOptionDialog(
                null,
                "¡Pechuga cocinada lista para ser desmechada y guiso para montar el arroz!",//mensaje del joption pane
                "Paso 5",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(45); 
    });
        JOptionPane.showOptionDialog(
                null,
                "oprime siguiente para iniciar a montar el arroz con su guizo",//mensaje del joption pane
                "Paso 6",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(48); 
    });
        JOptionPane.showOptionDialog(
                null,
                "iniciando a cocinar arroz......",//mensaje del joption pane
                "Paso 7",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(50); 
    });
        JOptionPane.showOptionDialog(
                null,
                " arroz listo para poner la tapa a la olla y secarse...........",//mensaje del joption pane
                "Paso 8",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(55); 
    });
        JOptionPane.showOptionDialog(
                null,
                "arroz seco y listo para el consumo",//mensaje del joption pane
                "Paso 9",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(65); 
    });
        JOptionPane.showOptionDialog(
                null,
                "oprime siguiente para desmechar la pechuga",//mensaje del joption pane
                "Paso 10",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(75); 
    });
        JOptionPane.showOptionDialog(
                null,
                "iniciando a desmechar la pechuga......",//mensaje del joption pane
                "Paso 11",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(85); 
    });
        JOptionPane.showOptionDialog(
                null,
                "Pechuga Desmechada y lista para unir con el arroz",//mensaje del joption pane
                "Paso 12",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(90); 
    });
        JOptionPane.showOptionDialog(
                null,
                "oprime siguiente para Poner revolver el pollo desmechado con el arroz y hechar salsas al gusto ",//mensaje del joption pane
                "Paso 13",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion,//array que creamos
                opcion[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(95); 
    });
        JOptionPane.showOptionDialog(
                null,
                "Revolviendo pollo desmechado con arroz y salsas......",//mensaje del joption pane
                "Paso 14",
                JOptionPane.DEFAULT_OPTION,//tipo de boton
                JOptionPane.INFORMATION_MESSAGE,//tipo de mensaje
                null,//sin icono personalizado
                opcion1,//array que creamos
                opcion1[0] //posicion dentro del array para iniciar en este caso 0 solo hay una opcion
        );
        SwingUtilities.invokeLater(() -> {
        progressBar.setValue(100); 
    });
         JOptionPane.showMessageDialog(null,Plato+" perfectamente preparado ,listo para ser consumido ....");
}
public static void main(String[] args) {
        progressBar = new JProgressBar(0, 100); 
        progressBar.setValue(0);
        progressBar.setStringPainted(true);
   JLabel coc=new JLabel("Selecciona un plato Para Cocinar :");
   String[] options = {"Arepas Caseras", "Ajiaco", "Arroz con pollo"};
   JComboBox<String> comboBox = new JComboBox<>(options);
   JButton cocinar=new JButton("Cocinar");
   
   cocinar.addActionListener(new ActionListener(){
       @Override
       public void actionPerformed(ActionEvent e) {
          String OPCIONCOMBO = (String) comboBox.getSelectedItem();
          if (OPCIONCOMBO.equals("Arepas Caseras")) {
                     cocinarArepas();
          } else if (OPCIONCOMBO.equals("Ajiaco")) {
                    cocinarAjiaco();
          } else if (OPCIONCOMBO.equals("Arroz con pollo")) {
                    cocinarArrozConPollo();
          }
            
       }
    });

     
   JPanel cocinapanel = new JPanel();
        cocinapanel.setLayout(new BoxLayout(cocinapanel, BoxLayout.Y_AXIS));
        cocinapanel.add(Box.createVerticalGlue()); // Espacio vertical al principio

        // Centrar el JLabel y el JComboBox
        JPanel labelPanel = new JPanel();
        labelPanel.add(coc);
        labelPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        cocinapanel.add(labelPanel);

        JPanel comboBoxPanel = new JPanel();
        comboBoxPanel.add(comboBox);
        comboBoxPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        cocinapanel.add(comboBoxPanel);

        cocinapanel.add(Box.createVerticalStrut(10));  // Espacio vertical

        // Centrar el JButton
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(cocinar);
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        cocinapanel.add(buttonPanel);
        
        JPanel progresbarPanel = new JPanel();
        progresbarPanel.add(progressBar);
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        cocinapanel.add(progresbarPanel);

        cocinapanel.add(Box.createVerticalGlue()); // Espacio vertical al final
   tabbedPane.addTab("Cocina", cocinapanel);
    }
}
