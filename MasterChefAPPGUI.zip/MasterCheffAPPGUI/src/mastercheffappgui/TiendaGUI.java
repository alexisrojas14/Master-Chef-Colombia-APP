/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author alexi
 */
public class TiendaGUI {
    public static void main(String[] args) {
         JFrame frameTienda = new JFrame("Tienda");
         
           DefaultTableModel tableModeltienda = new DefaultTableModel();

        // Agregar columnas al modelo de datos
        tableModeltienda.addColumn("Producto");
        tableModeltienda.addColumn("Precio");
        

        // Agregar filas al modelo de datos
        tableModeltienda.addRow(new Object[]{"Harina de Maiz 1 Kg", 4000});
        tableModeltienda.addRow(new Object[]{"Pechuga de Pollo", 15000});
        tableModeltienda.addRow(new Object[]{"Papa Pastusa 1 Kg", 5400});
        tableModeltienda.addRow(new Object[]{"Arroz Blanco Diana 500 Gr ", 4000});
        tableModeltienda.addRow(new Object[]{"Salsa De Tomate Doy Pack FRUCO 600 gr",13100});
        
        JTable productos=new JTable(tableModeltienda);
        JButton salir=new JButton("Salir Menu Principal");
        
        salir.addActionListener(new ActionListener(){
             @Override
             public void actionPerformed(ActionEvent e) {
                frameTienda.dispose();
             }
        });
        
         JScrollPane tableScrollPane = new JScrollPane(productos);
       // Usar GridBagLayout en lugar de GridLayout
            frameTienda.setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();

            // Configurar la tabla
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.weightx = 1.0;
            gbc.weighty = 1.0;
            frameTienda.add(tableScrollPane, gbc);

            // Configurar el botón
            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.weightx = 1.0;
            gbc.weighty = 0.0;
            frameTienda.add(salir, gbc);
        

        // Establecer el tamaño de la ventana
        frameTienda.setSize(600, 300);
        frameTienda.setLocationRelativeTo(null);

        // Establecer la operación de cierre predeterminada
        frameTienda.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Hacer que la ventana sea visible
        frameTienda.setVisible(true);

            
    }
}
        
       
    

