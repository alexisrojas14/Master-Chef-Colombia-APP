/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

/**
 *
 * @author alexi
 */
public abstract class Persona {
    private String Nombre;
    private String Nacionalidad;
    private int Edad;
    private String Profesion;
    
    public Persona(String Nombre,String Nacionalidad,int Edad,String Profesion){
        this.Nombre=Nombre;
        this.Nacionalidad=Nacionalidad;
        this.Edad=Edad;
        this.Profesion=Profesion;
    }
    
    public  String getNombre(){
        
        return Nombre;
    }
    public  String getNacionalidad(){
        
        return Nacionalidad;
    }
    public  int getEdad(){
        
        return Edad;
    }
    public  String getProfesion(){
        
        return Profesion;
    }
    
    public void setNombre(String Nombre){
        this.Nombre=Nombre;
    }
    public void setNacionalidad(String Nacionalidad){
        this.Nacionalidad=Nacionalidad;
    }
    public void setEdad(int Edad){
        this.Edad=Edad;
    }
    public void setProfesion(String Profesion){
        this.Profesion=Profesion;
    }
     @Override
    public String toString() {
        // Utiliza el formato que prefieras para mostrar la información de la persona
        return "\n Nombre: " + getNombre() +
               "\n Nacionalidad: " + getNacionalidad() +
               "\n Edad: " + getEdad() +
               "\n Profesión: " + getProfesion();
    }
}