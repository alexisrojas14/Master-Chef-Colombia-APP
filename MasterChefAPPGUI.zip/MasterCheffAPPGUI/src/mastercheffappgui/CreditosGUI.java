/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.time.Clock.system;
import static java.time.InstantSource.system;
import javax.swing.*;
import javax.swing.JPanel;
import static mastercheffappgui.MenuPrincipal.tabbedPane;
import static mastercheffappgui.RegistroInicioGUI.Usuario;

/**
 *
 * @author alexi
 */
public class CreditosGUI {
        public static void main(String[] args) {
           
        JPanel creditospanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets.bottom = 5;  // Espacio entre componentes

         JLabel cred =new JLabel("------------------------CREDITOS--------------------");
        creditospanel.add(cred, gbc);

        JLabel espacio =new JLabel("                ");
        creditospanel.add(espacio, gbc);

        JLabel nombre=new JLabel("Cristian Rojas");
        creditospanel.add(nombre, gbc);

        JLabel correo=new JLabel("cristian.rojas.herreno@pi.edu.co");
        creditospanel.add(correo, gbc);

        JLabel est=new JLabel("Estudiante Politecnico Internacional");
        creditospanel.add(est, gbc);

       JLabel clas=new JLabel("Estructura de Datos y Programacion 1 2023");
        creditospanel.add(clas, gbc);

        JButton cerrar=new JButton("Cerrar Programa");
        gbc.insets.bottom = 10;  // Espacio adicional después del botón
        creditospanel.add(cerrar, gbc);
        
         cerrar.addActionListener(new ActionListener(){
                 @Override
                 public void actionPerformed(ActionEvent e) {
                     JOptionPane.showMessageDialog(null,"!Hasta Luego "+Usuario+" un Gusto Que Hayas Disfrutado de Master Chef Colombia APP¡");
                    System.exit(0);
                   
                 }
            
        });
        
        tabbedPane.addTab("Creditos",creditospanel);
    }
}
