/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import javax.swing.*;

/**
 *
 * @author alexi
 */
public class MenuPrincipal extends JFrame {
    static JTabbedPane tabbedPane;//creamos un tabbedpane llamado awsi mismo 
    
    public MenuPrincipal(){//constructor 
        setTitle("Master Chef Colombia App");//titulo del tabbedpane
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);//tamaño  tabbed pane

        tabbedPane = new JTabbedPane();
        add(tabbedPane);
        String[] args = null;
      
        Recetastipicas.main(args);
        CocinaGUI.main(args);
        GanadoresGUI.main(args);
        JuradosGUI.main(args);
        PresentadoraGUI.main(args);
        OtrosProgramasGUI.main(args);
        CreditosGUI.main(args);

        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuPrincipal app = new MenuPrincipal();//instanciamos la clase como app
            app.setVisible(true);
        });
    }
}
