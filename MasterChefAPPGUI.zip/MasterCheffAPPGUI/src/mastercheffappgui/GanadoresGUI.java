/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import static mastercheffappgui.MenuPrincipal.tabbedPane;


/**
 *
 * @author Administrador
 */
class ganadores{
    private String Nombre;
    private String Profesion;
    private int Edad;
    private String Nacionalidad;
    private int Año;
    private String EstadoCivil;
   

//metodo constructor para inicializar los atributos 
public ganadores(String Nombre, String Profesion, int Edad, String Nacionalidad, int Año, String EstadoCivil) {
        this.Nombre = Nombre;
        this.Profesion = Profesion;
        this.Edad = Edad;
        this.Nacionalidad = Nacionalidad;
        this.Año = Año;
        this.EstadoCivil = EstadoCivil;
}

//METODO GET Y SET PARA OBTENER Y MODIFICAR LOS ATRIBUTOS DE LA CLASE GANADORES
public String getNombre(){
return Nombre;
}
public void setNombre(String Nombre){
this.Nombre = Nombre;
}

public String getProfesion(){
return Profesion;
}
public void setProfesion(String Profesion){
this.Profesion = Profesion;
}

public int getEdad(){
return Edad;
}
public void setEdad(int Edad){
this.Edad = Edad;
}

public String getNacionalidad(){
return Nacionalidad;  
}
public void setNacionalidad(String Nacionalidad){
    this.Nacionalidad =Nacionalidad;
}

public int getAño(){
return Año;
}
public void setAño(int Año){
this.Año = Año;
}

public String getEstadoCivil(){
return EstadoCivil;  
}
public void setEstadoCivil(String EstadoCivil){
    this.EstadoCivil =EstadoCivil;
}
public void GANADORESMASTERCHEFF(JTextArea textarea){
    textarea.append("\nGanador");
    textarea.append("\nNombre: "+Nombre+"\nProfesion:" +Profesion+"\nEdad: "+Edad+"\nNacionalidad: "+Nacionalidad+"\nAño Que Gano: "+Año+"\nEstado Civil:"+EstadoCivil);
    textarea.append("\n==============================");
}
}
public class GanadoresGUI {
     private static JTextArea textarea;
    public static void main(String[] args) {
        
        textarea = new JTextArea();
         textarea.setEditable(false);
        ganadores ramiro = new ganadores("ramiro meneses","actor",53,"colombiano",2022,"casado");
       
        ganadores carla = new ganadores("carla giraldo","actriz",37,"colombiana",2021,"casada");
        
        ganadores Adriana = new ganadores("adriana lucia","cantante",41,"colombiana",2020,"casada");
       
        ganadores piter  = new ganadores("piter albeiro","Humorista",46,"colombiano",2018,"soltero");
       
        ganadores leonardo = new ganadores("leonardo moran","diseñador",40,"colombiano",2016,"soltero");
        
        ramiro.GANADORESMASTERCHEFF(textarea);
        carla.GANADORESMASTERCHEFF(textarea);
        Adriana.GANADORESMASTERCHEFF(textarea);
        piter.GANADORESMASTERCHEFF(textarea);
        leonardo.GANADORESMASTERCHEFF(textarea);
        
        JLabel TEXT=new JLabel("Estos Son Los Ganadores de Master Cheff Colombia:");
        
        
        JScrollPane scrollPane = new JScrollPane(textarea);
       
       
        JPanel Ganadores=new JPanel();
        Ganadores.setLayout(new BoxLayout (Ganadores, BoxLayout.Y_AXIS));
        
        JPanel text=new JPanel();
        text.add(TEXT);
        text.setAlignmentX(Component.CENTER_ALIGNMENT);
        Ganadores.add(text);
        
       
       Ganadores.add(scrollPane);
       Ganadores.setAlignmentX(Component.CENTER_ALIGNMENT);
       
        
         tabbedPane.addTab("Ganadores", Ganadores);
    }
}
