/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mastercheffappgui;

import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import static mastercheffappgui.MenuPrincipal.tabbedPane;

/**
 *
 * @author Administrador
 */
// Definición de la interfaz para la Lista Abstracta
interface ListaAbstractaJurados<E> {
    void agregar(E elemento);  // Método para agregar un elemento a la lista
    E obtener(int indice);     // Método para obtener un elemento en un índice específico
    int tamaño();              // Método para obtener el tamaño de la lista
}

// Implementación de la Lista Abstracta usando un arreglo
class ListaArreglo<E> implements ListaAbstractaJurados<E>  {
    private Object[] elementos; // Arreglo para almacenar los elementos
    private int tamaño;         // Variable para rastrear el tamaño actual

    public ListaArreglo(int capacidadInicial) {
        elementos = new Object[capacidadInicial];
        tamaño = 0;
    }

    @Override
    public void agregar(E elemento) {
        // Verificar si es necesario aumentar la capacidad del arreglo
        if (tamaño == elementos.length) {
            Object[] nuevoArreglo = new Object[elementos.length * 2];
            System.arraycopy(elementos, 0, nuevoArreglo, 0, tamaño);
            elementos = nuevoArreglo;
        }

        // Agregar el elemento al final de la lista
        elementos[tamaño] = elemento;
        tamaño++;
    }

    @Override
    public E obtener(int indice) {
        // Verificar si el índice está dentro de los límites
        if (indice < 0 || indice >= tamaño) {
            throw new IndexOutOfBoundsException("Índice fuera de los límites");
        }

        // Obtener el elemento en el índice especificado
        @SuppressWarnings("unchecked")
        E elemento = (E) elementos[indice];
        return elemento;
    }

    @Override
    public int tamaño() {
        return tamaño;
    }
}
public class JuradosGUI extends Persona {//herencia con los atributos creados en la clase persona
    private static JTree TREE;//creacion de jtree
    private static ListaAbstractaJurados<String> lista = new ListaArreglo<>(3);//creacion lista usando la interfaz abstracta creada antes

       

    public JuradosGUI(String Nombre, String Nacionalidad, int Edad, String Profesion) {
        super(Nombre, Nacionalidad, Edad, Profesion);//variables creadas en la clase persona para usarlas en esta clase
    }
   
    
    //instanciamos nuevos objetos de la clase static para poder llamarlos en los metodos 
    static JuradosGUI Jorge=new JuradosGUI("Jorge Rausch","Colombiano",53,"Chef");
    static JuradosGUI nicolas=new JuradosGUI("nicolas de Zubiria","Colombiano",40,"Chef");
    static JuradosGUI cristopher=new JuradosGUI("Cristopher carpentier","chileno",50,"Chef");
    
     private static String obtenerInformacionJurado(String juradoSeleccionado) {//metodo string para mostrar info de cada objeto con variable para un switch case
      
        switch (juradoSeleccionado) {
            case " jurado 1"://si seleccionamos el nodo 1 
                return Jorge.toString(); //nos retorna la informacion de este objeto usando el metodo tostring creado en la clase persona
            case " jurado 2"://si seleccionamos el nodo 2
                return nicolas.toString(); //nos retorna la informacion de este objeto usando el metodo tostring creado en la clase persona
            case " jurado 3"://si seleccionamos el nodo 3
                return cristopher.toString();//nos retorna la informacion de este objeto usando el metodo tostring creado en la clase persona
            default:
                return "Información no disponible";//otra opcion este mensaje
        }
    }
   
     public static void juradosinfo(String juradoSeleccionado) {//metodo para mostrar la informacion de los objetos al seleccionar un nodo
        
        JFrame frameJuradoInfo = new JFrame("Información del Jurado");//creacion de jframe
        frameJuradoInfo.setSize(600, 300);//tamaño jframe
        frameJuradoInfo.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo la ventana actual al cerrar

        // Crear un JPanel para mostrar la información del jurado
        JPanel panelJuradoInfo = new JPanel();

        //creacion de variable string para mostrar la info del metodo obtener informacion
        String informacionJurado = obtenerInformacionJurado(juradoSeleccionado);

        JLabel labelInformacion = new JLabel(informacionJurado);//label para mostrar la info 

        // Agregar el JLabel al JPanel
        panelJuradoInfo.add(labelInformacion);

        // Agregar el JPanel al JFrame
        frameJuradoInfo.add(panelJuradoInfo);

        // Centrar la ventana en la pantalla
        frameJuradoInfo.setLocationRelativeTo(null);

        // Hacer visible el JFrame
        frameJuradoInfo.setVisible(true);
    }
     
      
     
    public static void main(String[] args) {
        
        // Agregar elementos a la lista abstracta
        lista.agregar(" jurado 1");
        lista.agregar(" jurado 2");
        lista.agregar(" jurado 3");
        
       DefaultMutableTreeNode root = new DefaultMutableTreeNode("Jurados MasterChef");//creamos el nodo de raiz 
         for (int i = 0; i < lista.tamaño(); i++) {//recorremos el tamaño de la lista
            String jurado = lista.obtener(i);//creamos una variable llamada jurado para crear un nodo con  cada  objeto de la lista 
            DefaultMutableTreeNode juradoNode = new DefaultMutableTreeNode(jurado);//creamos un nodo llamado jurado nodo
            root.add(juradoNode);//agregamos el nodo jurados al nodo principal llamado root
        }

        JTree tree = new JTree(root);//agregamos el nodo principal al jtree
        
       tree.addTreeSelectionListener(new TreeSelectionListener() {//accion de jtree
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
                // Verificar si el nodo no es nulo y es una hoja (no tiene hijos)
                if (selectedNode != null && selectedNode.isLeaf()) {//verifica si el nodo es nulo 
                    // Obtener el texto del nodo seleccionado
                    String juradoSeleccionado = selectedNode.getUserObject().toString();
                    // Crear y mostrar un JPanel con la información del jurado seleccionado
                    juradosinfo(juradoSeleccionado);//llamado de metodo el cual ejecuta jframe
                   
                }
                
            }
        });
       
        JScrollPane treeScrollPane = new JScrollPane(tree);//agregamos el jtree a un scrollpane
        
        JPanel Jurados =new JPanel();//creamos panel para poder ver el jtree
        Jurados.add(treeScrollPane);//agregamos el scrollpane al panel
    
     tabbedPane.addTab("Jurados", Jurados);//agregamos el panel al tabbedpane y le ponemos un nombre
    }

   
}
